import React from "react";
const curryear = new Date().getFullYear;

function Footer() {
  return (
    <footer>
      <p>
        Copyright @Prasadwilagama
        {curryear}
      </p>
      ;
    </footer>
  );
}

export default Footer;
//{curryear}
